# VPSMANAGER
SCRIPT MINERD MANAGER


apt-get update -y; apt-get upgrade -y; wget https://raw.githubusercontent.com/minerdso/VPSMANAGER/main/Plus; chmod 777 Plus;./Plus
